%Rishi Carlton
%A16828837
%HW2

%Question 1

%a
T = 300:100:1000;
P = 50000:10000:200000;
[P,T] = meshgrid(P,T');
p1a = van_der_Waals(P,T);


%b
figure(1)
surf(P,T,p1a)
title('Variance in Specific Volume for Pressure and Temperature')
xlabel('Pressure(Pa)')
ylabel('Temperature(K)')
zlabel('Specific Volume(m^3/kg)')
colorbar
shading interp
p1b = 'See figure 1'

%Question 2

%a
xi=[9000 10000 15000];
yi=[-43.42 -49.90 -56.50];
x=12000;
p2a = lagrange_interp(xi, yi, x)

%b
xi=[9000 10000 15000 20000];
yi=[-43.42 -49.90 -56.50 -56.60];
x=12000;
p2b = lagrange_interp(xi, yi, x)

%c
xi=[0 1000 2000 3000 4000 5000 6000 7000 8000 9000 10000 15000 20000];
yi=[15.00 8.50 2.00 -4.49 -10.98 -17.47 -23.96 -30.45 -36.94 -43.42 -49.90 -56.50 -56.60];
x=12000;
p2c = lagrange_interp(xi, yi, x)

%d
z=0:100:20000
xi=[0 1000 2000 3000 4000 5000 6000 7000 8000 9000 10000 15000 20000];
yi=[15.00 8.50 2.00 -4.49 -10.98 -17.47 -23.96 -30.45 -36.94 -43.42 -49.90 -56.50 -56.60];
x=z;
T=lagrange_interp(xi, yi, x);
figure(2)
plot(T,x,'g',yi,xi,'b.')
title('Interpolation of Temperature based on Altitude','Nodes')
legend('Interpolation','Nodes')
ylabel('Altitude(m)')
xlabel('Temperature(Degrees C)')
p2d = 'See figure 2'

%e
p2e='The interpolation is extremely accurate across all values of altitude. The graph of the interpolation and the nodes themselves line up perfectly.'








%%%%%%
% 
% {
%function [vn] = van_der_Waals(P, T)
% VAN_DER_WAALS returns the specific volume (m^3/kg) of water vapor 
% for a given pressure P (Pa) and temperature (K). The function solves
% for the root of the nonlinear van der Waals equations using Newton's
% method:
%   f(v) = P*v^3 - (P*b + RT)*v^2 + a*v - a*b,
% where R, a, b are given contants.
% The tolerance is set at 10^-6 and a maximum of 25 iterations are
% used to terminate the iteration.
% Call format: [vn] = van_der_Waals(P, T)


%% Set up physical parameters:
%{
R = 461.495;
a = 1703.28;
b = .00169099;
difference=1;
n = 0;
i=1;
j=1;
p1a=zeros(8,16)
%% Set up parameters for Newton's method:
max_iter = 25;
tol = 1e-6;

%% Define function f(v) and its derivative fp = df/fv
f = @(v) P(j).*v.^3 - (P(j).*b + R.*T(i)).*v.^2 + a.*v - a.*b;
fp = @(v) 3.*P(j).*v.^2.*v.*(R.*T(i)+b.*P(j))+a;

%% Define initial guess
%{
n = 0;
vn = R.*T(i)'./P(j) % assume ideal gas law


%{ Execute Newton's method:
for i=1:8
        for j=1:16
            vn = R.*T(i)'./P(j)
                while (n < max_iter & vn>10^-6)
                   % while difference>10^-6
                            %difference=(f(vn))./(fp(vn))
%vn = R.*T(i)'./P(j)
vn=vn-(f(vn))./(fp(vn));
%difference=(f(vn))./(fp(vn));
p1a(i,j)=vn
n=n+1;
                   % end    
                end
             %   if n==max_iter
             %       fprintf('Warning: Newton''s method did not converge within %d interations', max_iter);
             %   end
        end
        p1a
end %function van_der_Waals 

